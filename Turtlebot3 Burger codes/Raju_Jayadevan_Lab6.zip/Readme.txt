Team Vegeta:

We have used all 4 directories to train and test.
We have attached the code for training the model as well as testing (classifier.py).
Changing the directory of the datasets, commenting out lines which read any of the extra datasets and running the network should work fine.
