#!/usr/bin/env python3

import cv2
import sys
import csv
import time
import numpy as np
import sklearn
from sklearn.metrics import classification_report
from sklearn.svm import SVC
from sklearn import metrics
import random
### Load training images and labels
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPool2D
from tensorflow.keras.layers import Conv1D
from tensorflow.keras.layers import MaxPool1D
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Conv1D
from tensorflow.keras.layers import BatchNormalization

confusion_matrix = np.zeros((6, 6))

imageDirectory = '/home/abirath/Downloads/2023Simgs/S2023_imgs/'
imageDirectory1 = '/home/abirath/Downloads/2022Fheldout/'
imageDirectory2 = '/home/abirath/Downloads/2022Fimgs/'
imageDirectory3 = '/home/abirath/Downloads/2023Fimgs/'


with open(imageDirectory1 + 'train.txt', 'r') as f:
    reader1 = csv.reader(f)
    lines1 = list(reader1)


train1 = np.array([np.array(cv2.resize(cv2.imread(imageDirectory1 +lines1[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines1))])

train_data1 = train1.reshape(len(lines1), 33,25,3)
train_data1 = train_data1.astype(np.float32)

with open(imageDirectory + 'train.txt', 'r') as f:
    reader = csv.reader(f)
    lines = list(reader)


train = np.array([np.array(cv2.resize(cv2.imread(imageDirectory +lines[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines))])
train_data = train.reshape(len(lines), 33,25,3)
train_data = train_data.astype(np.float32)


with open(imageDirectory2 + 'train.txt', 'r') as f:
    reader2 = csv.reader(f)
    lines2 = list(reader2)


train2= np.array([np.array(cv2.resize(cv2.imread(imageDirectory2 +lines2[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines2))])
train_data2 = train2.reshape(len(lines2), 33,25,3)
train_data2 = train_data2.astype(np.float32)

with open(imageDirectory3 + 'train.txt', 'r') as f:
    reader3 = csv.reader(f)
    lines3 = list(reader3)


train3= np.array([np.array(cv2.resize(cv2.imread(imageDirectory3 +lines3[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines3))])
train_data3 = train3.reshape(len(lines3), 33,25,3)
train_data3 = train_data3.astype(np.float32)



X_train = np.concatenate((train_data, train_data1,train_data2,train_data3))
train_labels = np.array([np.int32(lines[i][1]) for i in range(len(lines))])
train_labels1 = np.array([np.int32(lines1[i][1]) for i in range(len(lines1))])
train_labels2 = np.array([np.int32(lines2[i][1]) for i in range(len(lines2))])
train_labels3 = np.array([np.int32(lines3[i][1]) for i in range(len(lines3))])
Y_train = np.concatenate((train_labels, train_labels1,train_labels2,train_labels3))


with open(imageDirectory + 'test.txt', 'r') as f:
    reader = csv.reader(f)
    lines = list(reader)

test = np.array([np.array(cv2.resize(cv2.imread(imageDirectory +lines[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines))])

test_data = test.reshape(len(lines), 33,25,3)
test_data = test_data.astype(np.float32)
test_labels = np.array([np.int32(lines[i][1]) for i in range(len(lines))])

with open(imageDirectory1 + 'test.txt', 'r') as f:
    reader1 = csv.reader(f)
    lines1= list(reader1)

test1= np.array([np.array(cv2.resize(cv2.imread(imageDirectory1 +lines1[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines1))])

test_data1 = test1.reshape(len(lines1), 33,25,3)
test_data1 = test_data1.astype(np.float32)
test_labels1 = np.array([np.int32(lines1[i][1]) for i in range(len(lines1))])

with open(imageDirectory2 + 'test.txt', 'r') as f:
    reader2 = csv.reader(f)
    lines2= list(reader2)

test2= np.array([np.array(cv2.resize(cv2.imread(imageDirectory2 +lines2[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines2))])

test_data2 = test2.reshape(len(lines2), 33,25,3)
test_data2 = test_data2.astype(np.float32)
test_labels2 = np.array([np.int32(lines2[i][1]) for i in range(len(lines2))])


with open(imageDirectory3 + 'test.txt', 'r') as f:
    reader3 = csv.reader(f)
    lines3= list(reader3)

test3= np.array([np.array(cv2.resize(cv2.imread(imageDirectory3 +lines3[i][0]+".jpg",cv2.IMREAD_COLOR),(33,25))) for i in range(len(lines3))])

test_data3 = test3.reshape(len(lines3), 33,25,3)
test_data3 = test_data3.astype(np.float32)
test_labels3 = np.array([np.int32(lines3[i][1]) for i in range(len(lines3))])

Y_test = np.concatenate((test_labels, test_labels1,test_labels2,test_labels3))
X_test= np.concatenate((test_data, test_data1,test_data2,test_data3))

print(X_train.shape)
print(X_test.shape)
print(Y_train.shape)
print(Y_test.shape)
X_train=X_train/255
X_test=X_test/255
model=Sequential()
model.add(Conv2D(128,(5,5),activation='relu',input_shape=(33,25,3)))

model.add(MaxPool2D(2,2))
model.add(BatchNormalization())
model.add(Conv2D(256,(3,3),activation='relu'))
model.add(MaxPool2D(2,2))
model.add(Flatten())
model.add(Dense(100,activation='relu'))
model.add(Dense(6,activation='softmax'))
model.compile(loss='sparse_categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
model.fit(X_train,Y_train,epochs=20)
model.evaluate(X_test,Y_test)
Y_pred = model.predict(X_test)
Y_pred_classes = np.argmax(Y_pred,axis = 1) 
# print(Y_pred_classes)

confusion_matrix += metrics.confusion_matrix(Y_test, Y_pred_classes)

print("\nConfusion Matrix:")
print(confusion_matrix)
