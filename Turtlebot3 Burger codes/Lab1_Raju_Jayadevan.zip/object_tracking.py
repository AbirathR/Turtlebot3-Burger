#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 15 10:53:52 2023

@authors: Abirath Raju & Sreeranj Jayadevan
"""

import cv2
import numpy as np
def empty(img):
    pass

video = cv2.VideoCapture(0)
cv2.namedWindow("Trackbar")
cv2.resizeWindow("TrackBar",600,300)
cv2.createTrackbar("hue_min","Trackbar",0,179,empty)
cv2.createTrackbar("hue_max","Trackbar",179,179,empty)
cv2.createTrackbar("sat_min","Trackbar",0,255,empty)
cv2.createTrackbar("sat_max","Trackbar",255,255,empty)
cv2.createTrackbar("val_min","Trackbar",0,255,empty)
cv2.createTrackbar("val_max","Trackbar",255,255,empty)


while True:
    ret, img=video.read()
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    hue_min = cv2.getTrackbarPos("hue_min","Trackbar")
    hue_max = cv2.getTrackbarPos("hue_max","Trackbar")
    sat_min = cv2.getTrackbarPos("sat_min","Trackbar")
    sat_max= cv2.getTrackbarPos("sat_max","Trackbar")
    val_min = cv2.getTrackbarPos("val_min","Trackbar")
    val_max = cv2.getTrackbarPos("val_max","Trackbar")
   
    lower = np.array([hue_min, sat_min, val_min])
    upper = np.array([hue_max, sat_max, val_max])
    mask=cv2.inRange(hsv, lower, upper)
    cnts, hei = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    for c in cnts:
        area = cv2.contourArea(c)
        #draw our contours
        if area>5000:
            #4 points it is a rectangle, 3 triangle, many circle 
            peri = cv2.arcLength(c,True)
            approx = cv2.approxPolyDP(c, 0.02*peri, True)
            x,y,w,h = cv2.boundingRect(c)
            cv2.rectangle(img, (x,y),(x+w,y+h),(0,255,0),2)
            print(x,y)
    cv2.imshow("Mask",mask)
    cv2.imshow("img",img)
    k=cv2.waitKey(1)
    if k == ord('q'):
        break
video.release()
cv2.destroyAllWindows()
