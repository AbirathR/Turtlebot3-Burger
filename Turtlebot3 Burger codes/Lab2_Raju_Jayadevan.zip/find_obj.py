# Bare Bones Code to View the Image Published from the Turtlebot3 on a Remote Computer
# Intro to Robotics Research 7785
# Georgia Institute of Technology
# Sean Wilson, 2022

########################################################################################################
# Team Vegeta (Abirath Raju, Sreeranj Jayadevan)
########################################################################################################
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
import numpy as np
import cv2
from cv_bridge import CvBridge
import geometry_msgs.msg


class DetectObjectNode(Node):
    def __init__(self):
        super().__init__('detect_object')
        self.declare_parameter('show_image_bool', True)
        self.declare_parameter('window_name', "Raw Image")

		#Determine Window Showing Based on Input
        self._display_image = bool(self.get_parameter('show_image_bool').value)

		# Declare some variables
        self._titleOriginal = self.get_parameter('window_name').value # Image Window Title	
		
		#Only create image frames if we are not running headless (_display_image sets this)
        if(self._display_image):
		# Set Up Image Viewing
            cv2.namedWindow(self._titleOriginal, cv2.WINDOW_AUTOSIZE ) # Viewing Window
            cv2.moveWindow(self._titleOriginal, 50, 50) # Viewing Window Original Location
        # Set up QoS Profiles for passing images over WiFi
        image_qos_profile = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.VOLATILE,
            depth=1)
        self._video_subscriber = self.create_subscription(
            CompressedImage,
            '/image_raw/compressed',
            self.image_callback,
            qos_profile=image_qos_profile)  # Use the specified QoS profile
        self.publisher = self.create_publisher(
            geometry_msgs.msg.Point,
            '/your/coordinate_topic',
            10)
        self.bridge = CvBridge()

    def image_callback(self, msg):
        self.cv_image = self.bridge.compressed_imgmsg_to_cv2(msg)

        try:
             x, y, w, h = self.detect_object(self.cv_image)
             #if(self._display_image):
              #   self.show_image(self.cv_image)
             if x is not None:
                 center_coordinates_msg = geometry_msgs.msg.Point()
                 center_coordinates_msg.x = x + w / 2
                 center_coordinates_msg.y = y + h / 2
                 self.publisher.publish(center_coordinates_msg)
             else:
                 center_coordinates_msg = geometry_msgs.msg.Point()
                 center_coordinates_msg.x = None
                 center_coordinates_msg.y = None
                 self.publisher.publish(center_coordinates_msg)
        except Exception as e:
             self.get_logger().error(f"Error processing image: {str(e)}")

        
            
    def show_image(self, img):
        cv2.imshow(self._titleOriginal, img)
		# Cause a slight delay so image is displayed
        self._user_input=cv2.waitKey(50) #Use OpenCV keystroke grabber for delay.

    def get_user_input(self):
        return self._user_input

    def detect_object(self, image_frame):
        hue_min = 20
        hue_max = 30
        sat_min = 50
        sat_max = 255
        val_min = 100
        val_max = 255

        hsv = cv2.cvtColor(image_frame, cv2.COLOR_BGR2HSV)
        lower = np.array([hue_min, sat_min, val_min])
        upper = np.array([hue_max, sat_max, val_max])
        mask = cv2.inRange(hsv, lower, upper)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        if len(cnts) != 0:
            x, y, w, h = self.draw_contours(mask, image_frame, cnts)
        else:
            return 10000, 10000, 10000, 10000

        return x, y, w, h

    def draw_contours(self, binary_image, color_image, contours):
        for c in contours:
            area = cv2.contourArea(c)
            print(area)
            if area > 3000:
                x, y, w, h = cv2.boundingRect(c)

                cv2.rectangle(color_image, (x, y), (x + w, y + h), (0, 255, 0), 2)

                return x, y, w, h
            #else:
                #return 0, 0, 0, 0


def main(args=None):
	rclpy.init() #init routine needed for ROS2.
	video_subscriber = DetectObjectNode() #Create class object to be used.

	while rclpy.ok():
		rclpy.spin_once(video_subscriber) # Trigger callback processing.
		if(video_subscriber._display_image):	
			if video_subscriber.get_user_input() == ord('q'):
				cv2.destroyAllWindows()
				break

	#Clean up and shutdown.
	video_subscriber.destroy_node()  
	rclpy.shutdown()

if __name__ == '__main__':
    main()
