# Bare Bones Code to View the Image Published from the Turtlebot3 on a Remote Computer
# Intro to Robotics Research 7785
# Georgia Institute of Technology
# Sean Wilson, 2022

########################################################################################################
# Team Vegeta (Abirath Raju, Sreeranj Jayadevan)
########################################################################################################
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
import cv2


class MinimalCoordinateSubscriber(Node):

    def __init__(self):		
		# Creates the node.
        super().__init__('minimal_video_subscriber')

		# Set Parameters
        self.declare_parameter('show_image_bool', True)
        self.declare_parameter('window_name', "Raw Image")

		#Determine Window Showing Based on Input
        self._display_image = bool(self.get_parameter('show_image_bool').value)

		# Declare some variables
        self._titleOriginal = self.get_parameter('window_name').value # Image Window Title	
        if(self._display_image):
		# Set Up Image Viewing
            cv2.namedWindow(self._titleOriginal, cv2.WINDOW_AUTOSIZE ) # Viewing Window
            cv2.moveWindow(self._titleOriginal, 50, 50) # Viewing Window Original Location
	
		#Set up QoS Profiles for passing images over WiFi
        image_qos_profile = QoSProfile(depth=5)
        image_qos_profile.history = QoSHistoryPolicy.KEEP_LAST
        image_qos_profile.durability = QoSDurabilityPolicy.VOLATILE 
        image_qos_profile.reliability = QoSReliabilityPolicy.BEST_EFFORT 

        print("Hello2")
		#Declare that the minimal_video_subscriber node is subcribing to the /camera/image/compressed topic.
        self._coordinate_subscriber = self.create_subscription(
				Point,'/your/coordinate_topic',self._rotate_callback,image_qos_profile)
        self._coordinate_subscriber # Prevents unused variable warning.
        self.ball_x_coord=None
        self.publisher=self.create_publisher(Twist,'/cmd_vel',10)
        self.timer=self.create_timer(0.25,self.timer_callback)

    def _rotate_callback(self, msg):	
		# The "CompressedImage" is transformed to a color image in BGR space and is store in "_imgBGR"
        
        if msg is None:
            return
        self.ball_x_coord=msg.x

        print(msg.x,msg.y)
    def timer_callback(self):
        robot_vel=Twist()
        if self.ball_x_coord == 15000:
            robot_vel.angular.z=0.0
        else:
            offset = 160 - self.ball_x_coord
            if offset>7:
                robot_vel.angular.z=0.15
            elif offset<-7:
                robot_vel.angular.z=-0.15
            else:
                robot_vel.angular.z=0.0
        self.publisher.publish(robot_vel)
				

def main():
	rclpy.init() #init routine needed for ROS2.
	coordinate_subscriber = MinimalCoordinateSubscriber() #Create class object to be used.
	
	while rclpy.ok():
		rclpy.spin_once(coordinate_subscriber) # Trigger callback processing.
	#Clean up and shutdown.
	coordinate_subscriber.destroy_node()  
	rclpy.shutdown()


if __name__ == '__main__':
	main()
