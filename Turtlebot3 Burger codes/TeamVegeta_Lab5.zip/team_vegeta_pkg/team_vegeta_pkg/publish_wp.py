########################################################################################################################################################################################
# Abirath Raju & Sreeranj Jayadevan - Team Vegeta
########################################################################################################################################################################################
import numpy as np
import rclpy
from rclpy.node import Node 
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
from geometry_msgs.msg import PoseStamped, Point, Quaternion, Pose
from nav2_msgs.action import NavigateToPose
from nav2_msgs.action._navigate_to_pose import NavigateToPose_FeedbackMessage
from action_msgs.msg import GoalStatus
from rclpy.action import ActionServer


class Wp_Class(Node):
    def __init__(self):
        super().__init__("Wp_Class")
        custom_qos_profile = QoSProfile(
            reliability = QoSReliabilityPolicy.BEST_EFFORT,
            history = QoSHistoryPolicy.KEEP_LAST,
            durability = QoSDurabilityPolicy.VOLATILE,
            depth = 1)

        self.wp_subscriber = self.create_subscription(
            NavigateToPose_FeedbackMessage,
            '/navigate_to_pose/_action/feedback',
            self.waypoint_callback,
            custom_qos_profile )
        self.wp_subscriber

        self.wp_publisher = self.create_publisher(PoseStamped, '/goal_pose', custom_qos_profile )
        self.wp_publisher
       
        self.waypoints = np.array([[1.723, -0.633, 0], [0.83, 0.612, 0], [0.145, -0.164, 0]])
        self.wp_idx = 0
        self.threshold = 0.25
        self.finished = False
        self.timer = self.create_timer(0.1,self.send_new_waypoint)
        
        #.send_new_waypoint()

    
    def waypoint_callback(self, msg):
        print("inside wp_call")
        if self.finished:
            return 
            
        feedback = msg.feedback
        p = feedback.current_pose.pose.position
        curr_pose = np.array([p.x, p.y, p.z])
        print("curr_pose",curr_pose)
        wp = self.waypoints[self.wp_idx]
        diff = wp - curr_pose 
        dist = np.sqrt(np.sum(diff ** 2))
        print("dist",dist)
        print(dist, wp)
        if dist < self.threshold:
            if self.wp_idx == 2:
                self.finished = True 
                return
                
            self.wp_idx += 1
            self.send_new_waypoint()


    def send_new_waypoint(self):
        print("inside send wp")
    	    
        x, y = self.waypoints[self.wp_idx, 0:2]
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        # msg.header.stamp.sec = 0
        # msg.header.stamp.nanosec = 0
        msg.header.frame_id = "map"
        pose = Pose()
        pose.position = Point()
        pose.orientation = Quaternion()
        pose.position.x = x 
        pose.position.y = y 
        pose.position.z = 0.0
        
        pose.orientation.x = 0.0
        pose.orientation.y = 0.0
        pose.orientation.z = 0.0
        pose.orientation.w = 1.0
        msg.pose = pose
        print("sending waypoint x: ", pose.position.x, ", y: ", pose.position.y)
        self.wp_publisher.publish(msg)
        

def main(args=None):
    rclpy.init()
    nav = Wp_Class()
    rclpy.spin(nav)

    nav.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
